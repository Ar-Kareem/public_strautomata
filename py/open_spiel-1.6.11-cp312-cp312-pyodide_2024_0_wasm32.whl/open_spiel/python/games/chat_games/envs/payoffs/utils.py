# Copyright 2023 DeepMind Technologies Limited
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Utils for defining payoff prompts.
"""

import dataclasses

from open_spiel.python.games.chat_games.envs.observations import summary


@dataclasses.dataclass(frozen=True)
class Payoff:
  query: str
  min: int
  max: int
  obs_trans_prefix: str = summary.PREFIX
  obs_trans_postfix: str = summary.POSTFIX
